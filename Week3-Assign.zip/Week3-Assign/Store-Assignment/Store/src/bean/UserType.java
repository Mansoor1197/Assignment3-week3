package bean;

public enum UserType {
	EMPLOYEE,AFFILLIATE,CUSTOMER;
}
