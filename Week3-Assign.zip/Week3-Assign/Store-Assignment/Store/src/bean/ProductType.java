package bean;

public enum ProductType {
	GROCERIES,OTHERS;
}
