package test;



import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import bean.Product;
import bean.ProductType;
import bean.User;
import bean.UserType;
import service.StoreService;
import service.StoreServiceImpl;

public class CustomerTest {
	
	@Test
	void test() {
		StoreService store=new StoreServiceImpl();
		List<Product> list=new ArrayList<Product>();
		Product product=new Product();
		Product product1=new Product();
		User user=new User();
		user.setUserId(2);
		user.setUserName("sai");
		user.setUsertype(UserType.CUSTOMER);
		user.setRegistrationDate(LocalDate.now());
		product.setProductId(50);
		product.setProductName("tomato");
		product.setProductType(ProductType.GROCERIES);
		product.setQuantity(10);
		product.setRatePerQuantity(10);
		list.add(product);
		product1.setProductId(100);
		product1.setProductName("bat");
		product1.setProductType(ProductType.OTHERS);
		product1.setQuantity(10);
		product1.setRatePerQuantity(10);
		list.add(product1);
		user.setProduct(list);
		double bill=store.calculateBill(user);
		System.out.println(bill);
		assertEquals(260, bill);
}
}