package test;





import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.Test;

import bean.Product;
import bean.ProductType;
import bean.User;
import bean.UserType;
import service.StoreService;
import service.StoreServiceImpl;


public class EmployeeTest {
	@Test
	void test() {
		StoreService store=new StoreServiceImpl();
		List<Product> list=new ArrayList<Product>();
		Product product=new Product();
		Product product1=new Product();
		User user=new User();
		user.setUserId(1);
		user.setUserName("Mansoor");
		user.setUsertype(UserType.EMPLOYEE);
		user.setRegistrationDate(LocalDate.now());
		product.setProductId(50);
		product.setProductName("brinjal");
		product.setProductType(ProductType.GROCERIES);
		product.setQuantity(10);
		product.setRatePerQuantity(10);
		list.add(product);
		product1.setProductId(100);
		product1.setProductName("pads");
		product1.setProductType(ProductType.OTHERS);
		product1.setQuantity(10);
		product1.setRatePerQuantity(10);
		list.add(product1);
		user.setProduct(list);
		double bill=store.calculateBill(user);
		System.out.println(bill);
		assertEquals(175, bill);
		}
}
