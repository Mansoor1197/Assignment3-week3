package service;

import bean.User;

public interface StoreService {
	public double calculateBill(User user);
	

}
